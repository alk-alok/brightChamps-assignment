import jwt from 'jsonwebtoken';
import { CustomError } from '../utils/customError.js';
import { User } from '../Models/user.model.js';

export const requireAuth = async (req, res, next) => {
  try {
    let userToken;

    // Check if token exists in headers
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer')) {
      userToken = authHeader.split(' ')[1];
    }

    if (!userToken) {
      return next(new CustomError('Please log in to access this feature', 401));
    }

    try {
      // Verify token
      const decodedToken = jwt.verify(userToken, process.env.JWT_SECRET);
      
      // Check if user still exists
      const currentUser = await User.findById(decodedToken.userId);
      if (!currentUser) {
        return next(new CustomError('User no longer exists', 401));
      }

      // Add user info to request
      req.user = {
        userId: currentUser._id,
        emailAddress: currentUser.emailAddress
      };
      
      next();
    } catch (error) {
      return next(new CustomError('Invalid token. Please log in again', 401));
    }
  } catch (error) {
    next(error);
  }
};