import express from "express";
import { validateInput } from "../middleware/validator.js";
import { requireAuth } from "../middleware/auth.js";
import { registerNewUser, loginUser, getCurrentUser} from "../controllers/auth.controller.js";

const router = express.Router();

router.post("/register", validateInput("registration"), registerNewUser);
router.post("/login", validateInput("login"), loginUser);
router.get("/me", requireAuth, getCurrentUser);

export default router;
